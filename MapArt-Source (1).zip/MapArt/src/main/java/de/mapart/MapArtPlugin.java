package de.mapart;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.server.MapInitializeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.MapMeta;
import org.bukkit.map.MapCanvas;
import org.bukkit.map.MapRenderer;
import org.bukkit.map.MapView;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MapArtPlugin extends JavaPlugin implements Listener, TabExecutor {

    private static final int SIZE = 128;
    private static final Set<String> EXTENSIONS = Set.of("png", "jpg", "jpeg", "gif", "bmp");

    private NamespacedKey artKey;
    private File imagesDir;
    private File mapsDir;

    private volatile int maxWidth;
    private volatile int maxHeight;
    private volatile int maxTiles;
    private volatile boolean cropMode;

    /** Spieler, deren Bild gerade verarbeitet wird (verhindert Mehrfachaufrufe). */
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();
    /** Zählt Logins pro Spieler, damit Karten nach einem Rejoin neu gezeichnet werden. */
    private final Map<UUID, Integer> sessions = new ConcurrentHashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();

        artKey = new NamespacedKey(this, "art");
        imagesDir = new File(getDataFolder(), "images");
        mapsDir = new File(getDataFolder(), "maps");
        imagesDir.mkdirs();
        mapsDir.mkdirs();

        getServer().getPluginManager().registerEvents(this, this);
        var command = getCommand("mapart");
        if (command != null) {
            command.setExecutor(this);
            command.setTabCompleter(this);
        }
    }

    private void loadSettings() {
        maxWidth = Math.max(1, getConfig().getInt("max-image-width", 2048));
        maxHeight = Math.max(1, getConfig().getInt("max-image-height", 2048));
        maxTiles = Math.max(1, getConfig().getInt("max-tiles", 64));
        cropMode = !"stretch".equalsIgnoreCase(getConfig().getString("scale-mode", "crop"));
    }

    // ------------------------------------------------------------------
    // Befehle
    // ------------------------------------------------------------------

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            help(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "apply" -> apply(sender, args);
            case "list" -> list(sender);
            case "info" -> info(sender);
            case "clear" -> clear(sender);
            case "reload" -> reload(sender);
            default -> help(sender);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("apply", "list", "info", "clear", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) out.add(s);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("apply")) {
            for (File f : imageFiles()) {
                if (f.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(f.getName());
                }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("apply")) {
            for (String s : List.of("scale", "tile")) {
                if (s.startsWith(args[2].toLowerCase(Locale.ROOT))) out.add(s);
            }
        }
        return out;
    }

    private void help(CommandSender s) {
        msg(s, "/mapart apply <datei> [scale|tile] - Bild in Karte(n) umwandeln", NamedTextColor.YELLOW);
        msg(s, "/mapart list - Verfügbare Bilder anzeigen", NamedTextColor.YELLOW);
        msg(s, "/mapart info - Anzahl deiner MapArt-Karten", NamedTextColor.YELLOW);
        msg(s, "/mapart clear - MapArt-Karten aus deinem Inventar entfernen", NamedTextColor.YELLOW);
        if (s.hasPermission("mapart.admin")) {
            msg(s, "/mapart reload - Config neu laden", NamedTextColor.YELLOW);
        }
    }

    private void list(CommandSender s) {
        List<File> files = imageFiles();
        if (files.isEmpty()) {
            msg(s, "Keine Bilder gefunden. Lege Dateien in plugins/MapArt/images/ ab.", NamedTextColor.RED);
            return;
        }
        msg(s, files.size() + " Bild(er):", NamedTextColor.GREEN);
        for (File f : files) {
            msg(s, " - " + f.getName(), NamedTextColor.GRAY);
        }
    }

    private void info(CommandSender s) {
        if (!(s instanceof Player p)) {
            msg(s, "Nur für Spieler.", NamedTextColor.RED);
            return;
        }
        int count = 0;
        for (ItemStack item : p.getInventory().getContents()) {
            if (isArt(item)) count += item.getAmount();
        }
        msg(s, "Du hast " + count + " MapArt-Karte(n) im Inventar.", NamedTextColor.GREEN);
    }

    private void clear(CommandSender s) {
        if (!(s instanceof Player p)) {
            msg(s, "Nur für Spieler.", NamedTextColor.RED);
            return;
        }
        int removed = 0;
        ItemStack[] contents = p.getInventory().getContents();
        for (int i = 0; i < contents.length; i++) {
            if (isArt(contents[i])) {
                removed += contents[i].getAmount();
                p.getInventory().setItem(i, null);
            }
        }
        msg(s, removed + " MapArt-Karte(n) entfernt.", NamedTextColor.GREEN);
    }

    private void reload(CommandSender s) {
        if (!s.hasPermission("mapart.admin")) {
            msg(s, "Keine Berechtigung.", NamedTextColor.RED);
            return;
        }
        reloadConfig();
        loadSettings();
        msg(s, "Config neu geladen.", NamedTextColor.GREEN);
    }

    private void apply(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            msg(sender, "Nur für Spieler.", NamedTextColor.RED);
            return;
        }
        if (args.length < 2) {
            msg(sender, "Benutzung: /mapart apply <datei> [scale|tile]", NamedTextColor.RED);
            return;
        }
        boolean tile = false;
        if (args.length >= 3) {
            if (args[2].equalsIgnoreCase("tile")) {
                tile = true;
            } else if (!args[2].equalsIgnoreCase("scale")) {
                msg(sender, "Modus muss scale oder tile sein.", NamedTextColor.RED);
                return;
            }
        }
        File file = resolveImage(args[1]);
        if (file == null) {
            msg(sender, "Bild nicht gefunden: " + args[1] + " (siehe /mapart list)", NamedTextColor.RED);
            return;
        }
        if (!busy.add(player.getUniqueId())) {
            msg(sender, "Es wird noch ein Bild von dir verarbeitet.", NamedTextColor.RED);
            return;
        }

        final boolean tileMode = tile;
        final String baseName = file.getName();
        msg(sender, "Verarbeite " + baseName + " ...", NamedTextColor.GRAY);

        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            try {
                BufferedImage src = ImageIO.read(file);
                if (src == null) throw new IOException("Kein gültiges Bildformat.");
                if (src.getWidth() > maxWidth || src.getHeight() > maxHeight) {
                    throw new IOException("Bild zu groß (max. " + maxWidth + "x" + maxHeight + ").");
                }
                int cols = tileMode ? (int) Math.ceil(src.getWidth() / (double) SIZE) : 1;
                int rows = tileMode ? (int) Math.ceil(src.getHeight() / (double) SIZE) : 1;
                if (cols * rows > maxTiles) {
                    throw new IOException("Zu viele Karten (" + (cols * rows) + ", max. " + maxTiles + ").");
                }
                List<BufferedImage> tiles = tileMode ? split(src, cols, rows) : List.of(scaleToMap(src));
                getServer().getScheduler().runTask(this, () -> deliver(player, baseName, tiles, cols, tileMode));
            } catch (Exception e) {
                getServer().getScheduler().runTask(this, () -> {
                    busy.remove(player.getUniqueId());
                    if (player.isOnline()) {
                        msg(player, "Fehler: " + e.getMessage(), NamedTextColor.RED);
                    }
                });
            }
        });
    }

    // ------------------------------------------------------------------
    // Karten erzeugen
    // ------------------------------------------------------------------

    private void deliver(Player player, String name, List<BufferedImage> tiles, int cols, boolean tileMode) {
        busy.remove(player.getUniqueId());
        if (!player.isOnline()) return;

        World world = player.getWorld();
        for (int i = 0; i < tiles.size(); i++) {
            BufferedImage img = tiles.get(i);
            MapView view = Bukkit.createMap(world);
            attach(view, img);
            saveAsync(view.getId(), img);

            String title = tileMode ? name + " (" + (i % cols + 1) + "," + (i / cols + 1) + ")" : name;
            ItemStack item = new ItemStack(Material.FILLED_MAP);
            MapMeta meta = (MapMeta) item.getItemMeta();
            meta.setMapView(view);
            meta.displayName(Component.text("MapArt: " + title, NamedTextColor.WHITE)
                    .decoration(TextDecoration.ITALIC, false));
            meta.getPersistentDataContainer().set(artKey, PersistentDataType.BYTE, (byte) 1);
            item.setItemMeta(meta);

            Map<Integer, ItemStack> leftover = player.getInventory().addItem(item);
            for (ItemStack rest : leftover.values()) {
                player.getWorld().dropItemNaturally(player.getLocation(), rest);
            }
        }
        msg(player, tiles.size() + " Karte(n) erstellt"
                + (tileMode ? " (" + cols + " Spalten, Reihenfolge: zeilenweise von oben links)." : "."),
                NamedTextColor.GREEN);
    }

    private void attach(MapView view, BufferedImage img) {
        for (MapRenderer r : new ArrayList<>(view.getRenderers())) {
            view.removeRenderer(r);
        }
        view.setScale(MapView.Scale.CLOSEST);
        view.setTrackingPosition(false);
        view.setUnlimitedTracking(false);
        view.setLocked(true);
        view.addRenderer(new ImageRenderer(this, img));
    }

    private void saveAsync(int mapId, BufferedImage img) {
        File out = new File(mapsDir, mapId + ".png");
        getServer().getScheduler().runTaskAsynchronously(this, () -> {
            try {
                ImageIO.write(img, "png", out);
            } catch (IOException e) {
                getLogger().warning("Konnte Karte " + mapId + " nicht speichern: " + e.getMessage());
            }
        });
    }

    /** Stellt gespeicherte Bilder nach einem Neustart wieder her. */
    @EventHandler
    public void onMapInit(MapInitializeEvent event) {
        File f = new File(mapsDir, event.getMap().getId() + ".png");
        if (!f.isFile()) return;
        try {
            BufferedImage img = ImageIO.read(f);
            if (img != null) attach(event.getMap(), img);
        } catch (IOException e) {
            getLogger().warning("Konnte Karte " + f.getName() + " nicht laden: " + e.getMessage());
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        sessions.merge(event.getPlayer().getUniqueId(), 1, Integer::sum);
    }

    int session(UUID id) {
        return sessions.getOrDefault(id, 0);
    }

    // ------------------------------------------------------------------
    // Bildverarbeitung
    // ------------------------------------------------------------------

    private BufferedImage scaleToMap(BufferedImage src) {
        BufferedImage out = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = out.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        g.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        if (cropMode) {
            int side = Math.min(src.getWidth(), src.getHeight());
            int sx = (src.getWidth() - side) / 2;
            int sy = (src.getHeight() - side) / 2;
            g.drawImage(src, 0, 0, SIZE, SIZE, sx, sy, sx + side, sy + side, null);
        } else {
            g.drawImage(src, 0, 0, SIZE, SIZE, null);
        }
        g.dispose();
        return out;
    }

    private List<BufferedImage> split(BufferedImage src, int cols, int rows) {
        List<BufferedImage> tiles = new ArrayList<>(cols * rows);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                BufferedImage t = new BufferedImage(SIZE, SIZE, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g = t.createGraphics();
                g.drawImage(src, 0, 0, SIZE, SIZE,
                        c * SIZE, r * SIZE, c * SIZE + SIZE, r * SIZE + SIZE, null);
                g.dispose();
                tiles.add(t);
            }
        }
        return tiles;
    }

    // ------------------------------------------------------------------
    // Hilfsfunktionen
    // ------------------------------------------------------------------

    private List<File> imageFiles() {
        List<File> out = new ArrayList<>();
        File[] files = imagesDir.listFiles();
        if (files == null) return out;
        for (File f : files) {
            if (f.isFile() && hasImageExtension(f.getName())) out.add(f);
        }
        out.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        return out;
    }

    private static boolean hasImageExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 && EXTENSIONS.contains(name.substring(dot + 1).toLowerCase(Locale.ROOT));
    }

    /** Löst den Dateinamen auf und stellt sicher, dass er im images-Ordner bleibt. */
    private File resolveImage(String name) {
        try {
            File base = imagesDir.getCanonicalFile();
            File f = new File(base, name).getCanonicalFile();
            if (!f.toPath().startsWith(base.toPath())) return null;
            if (!f.isFile() || !hasImageExtension(f.getName())) return null;
            return f;
        } catch (IOException e) {
            return null;
        }
    }

    private boolean isArt(ItemStack item) {
        if (item == null || item.getType() != Material.FILLED_MAP || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(artKey, PersistentDataType.BYTE);
    }

    private static void msg(CommandSender s, String text, NamedTextColor color) {
        s.sendMessage(Component.text("[MapArt] ", NamedTextColor.GOLD).append(Component.text(text, color)));
    }

    // ------------------------------------------------------------------
    // Renderer
    // ------------------------------------------------------------------

    private static final class ImageRenderer extends MapRenderer {
        private final MapArtPlugin plugin;
        private final BufferedImage image;
        private final Map<UUID, Integer> drawn = new HashMap<>();

        ImageRenderer(MapArtPlugin plugin, BufferedImage image) {
            super(true);
            this.plugin = plugin;
            this.image = image;
        }

        @Override
        public void render(MapView map, MapCanvas canvas, Player player) {
            UUID id = player.getUniqueId();
            int current = plugin.session(id);
            Integer last = drawn.get(id);
            if (last != null && last == current) return;
            canvas.drawImage(0, 0, image);
            drawn.put(id, current);
        }
    }
}
